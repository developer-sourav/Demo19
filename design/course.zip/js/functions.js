// JS OBFUSCATED =============== //
var _0xdb9c = ["\x77\x69\x64\x74\x68", "\x73\x68\x6F\x77", "\x68\x69\x64\x65", "\x73\x75\x70\x65\x72\x66\x69\x73\x68", "\x75\x6C\x2E\x73\x66\x2D\x6D\x65\x6E\x75", "\x76\x69\x73\x69\x62\x6C\x65", "\x30", "\x63\x73\x73", "\x2E\x70\x68\x6F\x74\x6F\x5F\x69\x63\x6F\x6E", "\x66\x61\x64\x65\x54\x6F", "\x73\x74\x6F\x70", "\x66\x69\x6E\x64", "\x68\x6F\x76\x65\x72", "\x2E\x70\x69\x63\x74\x75\x72\x65\x20\x61", "\x73\x63\x72\x6F\x6C\x6C\x54\x6F\x70", "\x73\x74\x69\x63\x6B\x79", "\x61\x64\x64\x43\x6C\x61\x73\x73", "\x6E\x61\x76", "\x72\x65\x6D\x6F\x76\x65\x43\x6C\x61\x73\x73", "\x73\x63\x72\x6F\x6C\x6C", "\x78\x61\x63\x74\x69\x76\x65", "\x73\x6C\x69\x64\x65\x54\x6F\x67\x67\x6C\x65", "\x2E\x73\x66\x2D\x6D\x65\x6E\x75", "\x63\x6C\x69\x63\x6B", "\x23\x6D\x6F\x62\x6E\x61\x76\x2D\x62\x74\x6E", "\x78\x70\x6F\x70\x64\x72\x6F\x70", "\x74\x6F\x67\x67\x6C\x65\x43\x6C\x61\x73\x73", "\x70\x61\x72\x65\x6E\x74", "\x2E\x6D\x6F\x62\x6E\x61\x76\x2D\x73\x75\x62\x61\x72\x72\x6F\x77", "\x66\x61\x64\x65\x49\x6E", "\x23\x74\x6F\x54\x6F\x70", "\x66\x61\x64\x65\x4F\x75\x74", "\x61\x6E\x69\x6D\x61\x74\x65", "\x62\x6F\x64\x79\x2C\x68\x74\x6D\x6C", "\x69\x6E\x6E\x65\x72\x57\x69\x64\x74\x68", "\x73\x6C\x6F\x77", "\x68\x74\x6D\x6C\x2C\x20\x62\x6F\x64\x79", "\x62\x75\x74\x74\x6F\x6E\x2E\x66\x6F\x72\x77\x61\x72\x64\x2C\x20\x62\x75\x74\x74\x6F\x6E\x2E\x62\x61\x63\x6B\x77\x6F\x72\x64", "\x61\x63\x74\x69\x76\x65", "\x2E\x74\x6F\x67\x67\x6C\x65\x64\x61\x74\x61", "\x6E\x65\x78\x74", "\x2E\x74\x6F\x67\x67\x6C\x65\x68\x61\x6E\x64\x6C\x65", "\x2E\x61\x6C\x65\x72\x74", "\x2E\x63\x6C\x6F\x73\x74\x61\x6C\x65\x72\x74", "\x74\x6F\x6F\x6C\x74\x69\x70", "\x2E\x74\x6F\x6F\x6C\x74\x69\x70\x2D\x31", "\x2E\x61\x63\x63\x72\x6F\x64\x69\x61\x6E\x2D\x64\x61\x74\x61", "\x2E\x61\x63\x63\x72\x6F\x64\x69\x61\x6E\x2D\x74\x72\x69\x67\x67\x65\x72", "\x66\x69\x72\x73\x74", "\x3A\x68\x69\x64\x64\x65\x6E", "\x69\x73", "\x73\x6C\x69\x64\x65\x55\x70", "\x73\x6C\x69\x64\x65\x44\x6F\x77\x6E", "\x70\x72\x65\x76\x65\x6E\x74\x44\x65\x66\x61\x75\x6C\x74", "\x6F\x6E", "\x68\x74\x6D\x6C", "\x2E\x70\x6F\x2D\x74\x69\x74\x6C\x65", "\x2E\x70\x6F\x2D\x62\x6F\x64\x79", "\x62\x6F\x64\x79", "\x74\x6F\x70", "\x70\x6F\x70\x6F\x76\x65\x72", "\x2E\x70\x6F\x2D\x6D\x61\x72\x6B\x75\x70\x20\x3E\x20\x2E\x70\x6F\x2D\x6C\x69\x6E\x6B", "\x69\x63\x6F\x6E\x2D\x70\x6C\x75\x73\x20\x69\x63\x6F\x6E\x2D\x6D\x69\x6E\x75\x73", "\x69\x2E\x69\x6E\x64\x69\x63\x61\x74\x6F\x72", "\x2E\x70\x61\x6E\x65\x6C\x2D\x68\x65\x61\x64\x69\x6E\x67", "\x70\x72\x65\x76", "\x74\x61\x72\x67\x65\x74", "\x68\x69\x64\x64\x65\x6E\x2E\x62\x73\x2E\x63\x6F\x6C\x6C\x61\x70\x73\x65", "\x23\x61\x63\x63\x6F\x72\x64\x69\x6F\x6E", "\x73\x68\x6F\x77\x6E\x2E\x62\x73\x2E\x63\x6F\x6C\x6C\x61\x70\x73\x65", "\x63\x61\x72\x6F\x75\x73\x65\x6C", "\x23\x71\x75\x6F\x74\x65\x2D\x63\x61\x72\x6F\x75\x73\x65\x6C", "\x72\x65\x61\x64\x79", "\x70\x6C\x61\x63\x65\x68\x6F\x6C\x64\x65\x72", "\x69\x6E\x70\x75\x74\x2C\x20\x74\x65\x78\x74\x61\x72\x65\x61"];
if ($(window)[_0xdb9c[0]]() > 767) {
    jQuery(_0xdb9c[4])[_0xdb9c[3]]({
        animation: {
            opacity: _0xdb9c[1]
        },
        animationOut: {
            opacity: _0xdb9c[2]
        }
    })
} else {
    jQuery(_0xdb9c[4])[_0xdb9c[3]]({
        animation: {
            opacity: _0xdb9c[5]
        },
        animationOut: {
            opacity: _0xdb9c[5]
        }
    })
};
$(_0xdb9c[8])[_0xdb9c[7]]({
    "\x6F\x70\x61\x63\x69\x74\x79": _0xdb9c[6]
});
$(_0xdb9c[13])[_0xdb9c[12]](function () {
    $(this)[_0xdb9c[11]](_0xdb9c[8])[_0xdb9c[10]]()[_0xdb9c[9]](800, 1)
}, function () {
    $(this)[_0xdb9c[11]](_0xdb9c[8])[_0xdb9c[10]]()[_0xdb9c[9]](800, 0)
});
$(window)[_0xdb9c[19]](function () {
    if ($(this)[_0xdb9c[14]]() > 1) {
        $(_0xdb9c[17])[_0xdb9c[16]](_0xdb9c[15])
    } else {
        $(_0xdb9c[17])[_0xdb9c[18]](_0xdb9c[15])
    }
});
$(_0xdb9c[24])[_0xdb9c[23]](function () {
    $(_0xdb9c[22])[_0xdb9c[21]](400)(_0xdb9c[20])
});
$(_0xdb9c[28])[_0xdb9c[23]](function () {
    $(this)[_0xdb9c[27]]()[_0xdb9c[26]](_0xdb9c[25])
});
$(function () {
    $(window)[_0xdb9c[19]](function () {
        if ($(this)[_0xdb9c[14]]() != 0) {
            $(_0xdb9c[30])[_0xdb9c[29]]()
        } else {
            $(_0xdb9c[30])[_0xdb9c[31]]()
        }
    });
    $(_0xdb9c[30])[_0xdb9c[23]](function () {
        $(_0xdb9c[33])[_0xdb9c[32]]({
            scrollTop: 0
        }, 500)
    })
});
if (window[_0xdb9c[34]] < 770) {
    $(_0xdb9c[37])[_0xdb9c[23]](function () {
        $(_0xdb9c[36])[_0xdb9c[32]]({
            scrollTop: 115
        }, _0xdb9c[35]);
        return false
    })
};
if (window[_0xdb9c[34]] < 500) {
    $(_0xdb9c[37])[_0xdb9c[23]](function () {
        $(_0xdb9c[36])[_0xdb9c[32]]({
            scrollTop: 245
        }, _0xdb9c[35]);
        return false
    })
};
if (window[_0xdb9c[34]] < 340) {
    $(_0xdb9c[37])[_0xdb9c[23]](function () {
        $(_0xdb9c[36])[_0xdb9c[32]]({
            scrollTop: 280
        }, _0xdb9c[35]);
        return false
    })
};
$(_0xdb9c[41])[_0xdb9c[23]](function () {
    $(this)[_0xdb9c[26]](_0xdb9c[38]);
    $(this)[_0xdb9c[40]](_0xdb9c[39])[_0xdb9c[21]]()
});
$(_0xdb9c[43])[_0xdb9c[23]](function () {
    $(this)[_0xdb9c[27]](_0xdb9c[42])[_0xdb9c[31]]()
});
$(_0xdb9c[45])[_0xdb9c[44]]({
    html: true
});
var $acdata = $(_0xdb9c[46]),
    $acclick = $(_0xdb9c[47]);
$acdata[_0xdb9c[2]]();
$acclick[_0xdb9c[48]]()[_0xdb9c[16]](_0xdb9c[38])[_0xdb9c[40]]()[_0xdb9c[1]]();
$acclick[_0xdb9c[54]](_0xdb9c[23], function (_0x42aax3) {
    if ($(this)[_0xdb9c[40]]()[_0xdb9c[50]](_0xdb9c[49])) {
        $acclick[_0xdb9c[18]](_0xdb9c[38])[_0xdb9c[40]]()[_0xdb9c[51]](300);
        $(this)[_0xdb9c[26]](_0xdb9c[38])[_0xdb9c[40]]()[_0xdb9c[52]](300)
    };
    _0x42aax3[_0xdb9c[53]]()
});
$(_0xdb9c[61])[_0xdb9c[60]]({
    trigger: _0xdb9c[12],
    html: true,
    title: function () {
        return $(this)[_0xdb9c[27]]()[_0xdb9c[11]](_0xdb9c[56])[_0xdb9c[55]]()
    },
    content: function () {
        return $(this)[_0xdb9c[27]]()[_0xdb9c[11]](_0xdb9c[57])[_0xdb9c[55]]()
    },
    container: _0xdb9c[58],
    placement: _0xdb9c[59]
});

function toggleChevron(_0x42aax3) {
    $(_0x42aax3[_0xdb9c[66]])[_0xdb9c[65]](_0xdb9c[64])[_0xdb9c[11]](_0xdb9c[63])[_0xdb9c[26]](_0xdb9c[62])
}
$(_0xdb9c[68])[_0xdb9c[54]](_0xdb9c[67], toggleChevron);
$(_0xdb9c[68])[_0xdb9c[54]](_0xdb9c[69], toggleChevron);
$(_0xdb9c[68])[_0xdb9c[54]](_0xdb9c[67], function () {});
$(document)[_0xdb9c[72]](function () {
    $(_0xdb9c[71])[_0xdb9c[70]]({
        pause: true,
        interval: 6000
    })
});
$(_0xdb9c[74])[_0xdb9c[73]]()

$(document).ready(function() {

    var counters = $(".count-title");
    var countersQuantity = counters.length;
    var counter = [];
  
    for (i = 0; i < countersQuantity; i++) {
      counter[i] = parseInt(counters[i].innerHTML);
    }
  
    var count = function(start, value, id) {
      var localStart = start;
      setInterval(function() {
        if (localStart < value) {
          localStart++;
          counters[id].innerHTML = localStart;
        }
      }, 40);
    }
  
    for (j = 0; j < countersQuantity; j++) {
      count(0, counter[j], j);
    }
  });